UNIFIED OBJECT — INTEGRATION HANDOFF
24 October 2026

This package aligns the Fusion decision engine with the recovered current
proposal in the session Design Unified Physical Object. Open
Integration_Handoff.html for the architecture, mathematical issue,
first shared experiment, and exact handoff boundaries.

Run from this extracted directory with Python 3.10+:

    python fusion_engine.py --out fusion_regression_results.json
    python object_adapter.py

No additional packages are needed. The first command replays the original
600 exact checks. The second writes the exact synthetic plunger fixture
and adapter results, including16 grouped panel checks and malformed-input
rejections. It issues no hardware commands.

The model parameters and force values are illustrative, not measured clay
properties. Calibration validity for the proposed object is not established.
The actions in the fixture report a memory class; they are not motor moves.

acquisition_contract.json records the recovered proposed architecture and
leaves unverified sensor, clock, calibration, and geometry fields unset.
repository_handoff.json describes proposed responsibilities; no repository
API or commit integration has been verified or executed here.

object_adapter.py adds native-unit, per-hypothesis closed intervals,
multi-feature acquisition groups charged once, tri-state action evidence,
and runtime filtering of actual transcripts. A typed metadata check does
not authenticate a real calibration or laboratory event.

Only fixed common-reset probes or fully modeled complete protocols are
covered. Rectangular outer bounds are conservative. Unresolved action
evidence is kept separate from proven physical infeasibility.

To use in the other session, provide this package and ask it to fill the
acquisition contract from its actual drawings and acquisition design.
The hardware and math work then meet at the same first memory experiment.
